import { calculateInvestmentResults, formatter } from '../util/investment'
export default function InversmentResult({ inputValues }) {
    const InversementResult = calculateInvestmentResults(inputValues);
    const initialInverstment = InversementResult[0].valueEndOfYear - InversementResult[0].interest - InversementResult[0].annualInvestment;
    console.log(inputValues);
    return (
        <table id="result">
            <thead>
                <tr>
                    <th>Year</th>
                    <th>Inversement Value</th>
                    <th>Intrest (Year)</th>
                    <th>Total Intrest</th>
                    <th>Invested Capital</th>
                </tr>
            </thead>
            <tbody>
                {InversementResult.map((investDetail) => {
                    const totalInterst = investDetail.valueEndOfYear - investDetail.annualInvestment * investDetail.year - initialInverstment;
                    const inverstCapital=investDetail.valueEndOfYear-totalInterst
                    return (<tr key={investDetail.year}>
                        <td>{investDetail.year}</td>
                        <td>{formatter.format(investDetail.valueEndOfYear)}</td>
                        <td>{formatter.format(investDetail.interest)}</td>
                        <td>{formatter.format(totalInterst)}</td>
                        <td>{formatter.format(inverstCapital)}</td>
                    </tr>)
                })}
                {/* <tr>
                    <td>klsd</td>
                    <td>klsd</td>
                    <td>klsd</td>
                    <td>klsd</td>
                    <td>klsd</td>
                </tr> */}
            </tbody>
        </table>
    )
}