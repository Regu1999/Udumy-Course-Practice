import { useState, useRef } from "react"
import ResultModel from './ResultModel.jsx';
export default function TimerChallenge({ title, targetTime }) {
    const timer = useRef();
    const modelBox = useRef();

    const [timeReamining, setTimeReamining] = useState(targetTime * 1000);
    const timerIsActive = timeReamining > 0 && timeReamining < targetTime * 1000;
    // const [timeStarted, setTimeStarted] = useState(false)
    // const [timerExpired, setTimerExpired] = useState(false);
    if (timeReamining <= 0) {
        clearInterval(timer.current);
        modelBox.current.open()
    }
    function resetRemainingTime(){
        setTimeReamining(targetTime * 1000);
    }
    function handleStart() {
        timer.current = setInterval(() => {
            setTimeReamining(prevTimeRemining => prevTimeRemining - 10);
        }, 10)
    }
    function handleStop() {
        clearInterval(timer.current);
        modelBox.current.open()
        // setTimeReamining(targetTime * 1000);
    }
    return (
        <>
            <ResultModel targetTime={targetTime} timeReamining={timeReamining} ref={modelBox} handleRemaningTime={resetRemainingTime} />
            <section className="challenge">
                <h2>{title}</h2>
                <p className="challenge-time">
                    {targetTime} second{targetTime > 1 ? "s" : ""}
                </p>
                <p>
                    <button onClick={timerIsActive ? handleStop : handleStart}>{timerIsActive ? 'Stop' : 'Start'} chalenge</button>
                </p>
                <p className={timerIsActive ? 'active' : undefined}>
                    {timerIsActive ? 'Time is runnning' : 'Time is Inactive'}
                </p>

            </section>
        </>
    )
}