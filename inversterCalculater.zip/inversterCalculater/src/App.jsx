import { useState } from "react"
import InversmentHeader from "./Component/InversmentHeader"
import UserInput from "./Component/UserInputs"
import InversmentResult from "./Component/InversementResult"
// import { calculateInvestmentResults } from "./util/investment"
function App() {
  const [inputValues,setInputValues]=useState({
    initialInvestment:15_000,
    annualInvestment:1000,
    expectedReturn:6,
    duration:10
})

const durationIsValid= inputValues.duration>0

function handleinputClick(inputValue, valueType){
    setInputValues(prevInputVal=>{
        return {
            ...prevInputVal,
            [valueType]:+inputValue
        }
    })
}

  return (
    <>
      <InversmentHeader />
      <section>
        <UserInput inputValues={inputValues} onInputChange={handleinputClick}/>
      </section>
      <section>
        {durationIsValid ? <InversmentResult inputValues={inputValues} />: <p className="center">Please Enter Valid Duration data</p>}
      </section>
    </>
  )
}

export default App
