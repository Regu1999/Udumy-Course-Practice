// import {calculateInvestmentResults} from '../util/investment'
import { useState } from "react"
export default function UserInput({inputValues,onInputChange}) {

    return (
        <div id="user-input">
            <div className="input-group">
                <div>
                    <label htmlFor="">Initial Iversment</label>
                    <input type="number" value={inputValues.initialInvestment} onChange={(e)=> onInputChange(e.target.value,"initialInvestment")} required/>
                </div>
                <div>
                    <label htmlFor="">Anual Inversment</label>
                    <input type="number" value={inputValues.annualInvestment} onChange={(e)=> onInputChange(e.target.value,"annualInvestment")} required/>
                </div>

            </div>
            <div className="input-group">
                <div>
                    <label htmlFor="">Expeted Return</label>
                    <input type="number" value={inputValues.expectedReturn} onChange={(e)=> onInputChange(e.target.value,"expectedReturn")} required/>
                </div>
                <div>
                    <label htmlFor="">Duration</label>
                    <input type="number" value={inputValues.duration} onChange={(e)=> onInputChange(e.target.value,"duration")} required/>
                </div>
            </div>
        </div>
    )
}