import ReactDOM, { createPortal } from 'react-dom'
import { forwardRef, useImperativeHandle, useRef } from "react"
const ResultModel = forwardRef(function ({ targetTime, timeReamining, handleRemaningTime }, ref) {
    let formatingReminingTime = (timeReamining / 1000).toFixed(2)
    const getLost = timeReamining <= 0;
    const score=Math.round((1-timeReamining/(targetTime*1000))*100)
    const dialogModel = useRef()
    useImperativeHandle(ref, () => {
        return {
            open() {
                dialogModel.current.showModal();
            },
        }
    })
    return createPortal(
        <dialog className="result-modal" ref={dialogModel} onClose={handleRemaningTime}>
             {getLost && <h2>You Loose</h2>}
             {!getLost&& <h2>Your Score is:{score}</h2>}
            <p>Target time was <strong>{targetTime} seconds.</strong></p>
            <p>You stopped the timer with <strong>{formatingReminingTime} seconds left.</strong></p>
            <form method="dialog">
                <button>Close</button>
            </form>
        </dialog>,
        document.getElementById("modal")
    )
})

export default ResultModel