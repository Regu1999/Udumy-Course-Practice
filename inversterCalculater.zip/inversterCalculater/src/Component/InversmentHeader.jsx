import Logo from '../assets/investment-calculator-logo.png'
export default function InversmentHeader(){
    return (
        <header id="header">
            <img src={Logo} alt="logo" />
            <h1>Inversement Calculater</h1>
        </header>
    )
}